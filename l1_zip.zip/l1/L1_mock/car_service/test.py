class InvalidException(Exception):
    message=""
    def __init__(self,message):
        super().__init__(message)
        self.message=message

import re
ls=[]
with open('CarDetails_5.txt') as f:
    reader=f.read().split("\n")
    for i in reader:
        w=i.split(",")
        if int(w[4])>5:
            ls.append(w)

print(ls)

def validate(str):
    res=re.search("^(NXF)[0-9]{3}.{3}[a-zA-Z]$",str)
    if res==None:
        raise InvalidException("Invalid ID")
    else:
        return True
    
validate("NXFfwehjvfh")
