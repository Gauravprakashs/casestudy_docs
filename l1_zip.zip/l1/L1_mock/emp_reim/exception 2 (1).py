from email import message

class InvalidRequestIdException(Exception):
    message=""
    #Create the constructor here
    def __init__(self, message):
        super().__init__(message)
        self.message= message
